"""
python wrapper for whatsapp. No Selenium needed! 
Thanks to Whatsmeow's golang native library, Whatsmeow implementation will make this code 'hopefully' python newcomers friendly without sacrificing its speed and perfomances.
"""

import os
import sys
import logging

LOGGER = logging.getLogger()
