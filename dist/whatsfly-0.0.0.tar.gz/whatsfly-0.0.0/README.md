WhatsApp wrapper in Python. No selenium needed. Just run and have fun. Just try and go fly. 

Thanks to Whatsmeow for amazing works. Inspired from tls-client, tiktoken, and whatsmeow.
