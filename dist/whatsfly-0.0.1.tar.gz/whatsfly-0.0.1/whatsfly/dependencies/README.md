# notes on building the main.go file

## The build.sh file was borrowed from https://github.com/bogdanfinn/tls-client/blob/master/cffi_dist/build.sh

## make sure you have installed all build tools on your machine

# trashy notes
-  python setup.py sdist
cd whatsfly 
make sure u on setup.py dir
- pip install .